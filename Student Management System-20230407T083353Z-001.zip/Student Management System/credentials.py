# User Credentials
host = 'localhost'
user = 'root'
password = 'root123'
database = 'student_management'
port=3306
'''student management system project in python using tkinter and mysql'''
from functools import partial
from tkinter import *
from tkinter import messagebox
import pymysql
import custom as cs
import credentials as cr
from tkinter import  ttk

class FeesManagement:
    def __init__(self, root):
        self.window = root
        self.window.title("Student Management System")
        self.window.geometry("780x480")
        self.window.config(bg = "white")

        # Customization
        self.color_1 = cs.color_1
        self.color_2 = cs.color_2
        self.color_3 = cs.color_3
        self.color_4 = cs.color_4
        self.font_1 = cs.font_1
        self.font_2 = cs.font_2

        # User Credentials
        self.host = cr.host
        self.user = cr.user
        self.password = cr.password
        self.database = cr.database
        self.port=cr.port

        # Left Frame
        self.frame_1 = Frame(self.window, bg=self.color_1)
        self.frame_1.place(x=0, y=0, width=540, relheight = 1)

        # Right Frame
        self.frame_2 = Frame(self.window, bg = self.color_2)
        self.frame_2.place(x=540,y=0,relwidth=1, relheight=1)

        # Buttons
        self.add_bt = Button(self.frame_2, text='Add Fees', font=(self.font_1, 12), bd=2, command=self.GetContact_Add, cursor="hand2", bg=self.color_2,fg=self.color_3).place(x=68,y=40,width=100)
        self.view_bt = Button(self.frame_2, text='View Details', font=(self.font_1, 12), bd=2, command=self.GetContact_View, cursor="hand2", bg=self.color_2,fg=self.color_3).place(x=68,y=100,width=100)
        self.clear_bt = Button(self.frame_2, text='Clear', font=(self.font_1, 12), bd=2, command=self.ClearScreen, cursor="hand2", bg=self.color_2,fg=self.color_3).place(x=68,y=280,width=100)
        self.exit_bt = Button(self.frame_2, text='Exit', font=(self.font_1, 12), bd=2, command=self.Exit, cursor="hand2", bg=self.color_2,fg=self.color_3).place(x=68,y=340,width=100)


    def ShowDetails(self,row):
        feedetails = ttk.Treeview(self.frame_1)

        feedetails['columns'] = ('ID', 'Amount', 'Mode', 'For Year', 'Description')
        feedetails.column("#0", width=0, stretch=NO)
        feedetails.column("ID", anchor=CENTER, width=80)
        feedetails.column("Amount", anchor=CENTER, width=80)
        feedetails.column("Mode", anchor=CENTER, width=100)
        feedetails.column("For Year", anchor=CENTER, width=80)
        feedetails.column("Description", anchor=CENTER, width=80)

        feedetails.heading("#0", text="", anchor=CENTER)
        feedetails.heading("ID", text="Id", anchor=CENTER)
        feedetails.heading("Amount", text="Amount", anchor=CENTER)
        feedetails.heading("Mode", text="Mode", anchor=CENTER)
        feedetails.heading("For Year", text="Year", anchor=CENTER)
        feedetails.heading("Description", text="Description", anchor=CENTER)

        try:
            connection = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database,
                                         port=self.port)
            curs = connection.cursor()
            curs.execute("select * from fees where contact=%s", row[8])
            data = curs.fetchall()

            for v in data:
                feedetails.insert(parent='', index='end', iid=0, text='',
                        values=(v[0], v[2], v[5],v[3], v[4]))


            connection.close()
            feedetails.place(x=50,y=200,width=450,height=200)
        except Exception as e:
            messagebox.showerror("Error!", f"Error due to {str(e)}", parent=self.window)

    '''Widgets for adding student data'''
    def AddFees(self,row):
        self.ClearScreen()

        self.name = Label(self.frame_1, text="First Name", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=40,y=30)
        self.name_entry = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.name_entry.insert(0, row[0])
        self.name_entry.place(x=40,y=60, width=200)

        self.surname = Label(self.frame_1, text="Last Name", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=300,y=30)
        self.surname_entry = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.surname_entry.insert(0, row[1])
        self.surname_entry.place(x=300,y=60, width=200)

        self.course = Label(self.frame_1, text="Course", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=40,y=100)
        self.course_entry = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.course_entry.place(x=40,y=130, width=200)
        self.course_entry.insert(0, row[2])

        self.amount = Label(self.frame_1, text="Amount", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=300,y=100)
        self.amount_entry = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.amount_entry.place(x=300,y=130, width=200)

        self.mode = Label(self.frame_1, text="Mode", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=40,y=170)
        modes = ["Cash", "Cheque", "Online Transfer"]
        self.cbModes = ttk.Combobox(self.frame_1, text="Payment mode", values=modes)
        self.cbModes.place(x=40,y=200, width=200)

        self.desc = Label(self.frame_1, text="Description", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=300,y=170)
        self.desc = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.desc.place(x=300,y=200, width=200)

        self.contact = Label(self.frame_1, text="Contact", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=40,
                                                                                                       y=260)
        self.contact_entry = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.contact_entry.insert(0, row[8])
        self.contact_entry.place(x=40, y=290, width=200)

        self.year = Label(self.frame_1, text="Year", font=(self.font_2, 15, "bold"), bg=self.color_1).place(x=240, y=260)
        self.year_entry = Entry(self.frame_1, bg=self.color_4, fg=self.color_3)
        self.year_entry.insert(0, row[5])
        self.year_entry.place(x=300, y=290, width=200)

        self.submit_bt_1 = Button(self.frame_1, text='Submit', font=(self.font_1, 12), bd=2, command=self.Submit, cursor="hand2", bg=self.color_2,fg=self.color_3).place(x=200,y=389,width=100)

    '''Get the contact number to show a student details'''

    def GetContact_Add(self):
        self.ClearScreen()

        self.getInfo = Label(self.frame_1, text="Enter Phone Number", font=(self.font_2, 18, "bold"),
                             bg=self.color_1).place(x=140, y=70)
        self.getInfo_entry = Entry(self.frame_1, font=(self.font_1, 12), bg=self.color_4, fg=self.color_3)
        self.getInfo_entry.place(x=163, y=110, width=200, height=30)
        self.submit_bt_2 = Button(self.frame_1, text='Submit', font=(self.font_1, 10), bd=2,
                                  command=self.CheckContact_Add, cursor="hand2", bg=self.color_2,
                                  fg=self.color_3).place(x=220, y=150, width=80)

    '''Get the contact number to show a student details'''
    def GetContact_View(self):
        self.ClearScreen()

        self.getInfo = Label(self.frame_1, text="Enter Phone Number", font=(self.font_2, 18, "bold"), bg=self.color_1).place(x=140,y=70)
        self.getInfo_entry = Entry(self.frame_1, font=(self.font_1, 12), bg=self.color_4, fg=self.color_3)
        self.getInfo_entry.place(x=163, y=110, width=200, height=30)
        self.submit_bt_2 = Button(self.frame_1, text='Submit', font=(self.font_1, 10), bd=2, command=self.CheckContact_View, cursor="hand2", bg=self.color_2,fg=self.color_3).place(x=220,y=150,width=80)
            

    '''Remove all widgets from the frame 1'''
    def ClearScreen(self):
        for widget in self.frame_1.winfo_children():
            widget.destroy()

    '''Exit window'''
    def Exit(self):
        self.window.destroy()



    '''
    Checks whether the contact number is available or not. If available, 
    the function calls the 'ShowDetails' function to display the result.
    '''
    def CheckContact_View(self):
        if self.getInfo_entry.get() == "":
            messagebox.showerror("Error!", "Please enter your contact number",parent=self.window)
        else:
            try:
                connection = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database,port=self.port)
                curs = connection.cursor()
                curs.execute("select * from student_register where contact=%s", self.getInfo_entry.get())
                row=curs.fetchone()
                
                if row == None:
                    messagebox.showerror("Error!","Contact number doesn't exists",parent=self.window)
                else:
                    self.ShowDetails(row)
                    connection.close()
            except Exception as e:
                messagebox.showerror("Error!",f"Error due to {str(e)}",parent=self.window)

    '''
        Check   s whether the contact number is available or not. If available, 
        the function calls the 'GetUpdateDetails' function to get the new data to perform
        update operation.
        '''

    def CheckContact_Add(self):
        if self.getInfo_entry.get() == "":
            messagebox.showerror("Error!", "Please enter your contact number", parent=self.window)
        else:
            try:
                connection = pymysql.connect(host=self.host, user=self.user, password=self.password,
                                             database=self.database,port=self.port)
                curs = connection.cursor()
                curs.execute("select * from student_register where contact=%s", self.getInfo_entry.get())
                row = curs.fetchone()

                if row == None:
                    messagebox.showerror("Error!", "Contact number doesn't exists", parent=self.window)
                else:
                    self.AddFees(row)
                    connection.close()
            except Exception as e:
                messagebox.showerror("Error!", f"Error due to {str(e)}", parent=self.window)


    

    
    '''It adds the information of new students'''
    def Submit(self):
        if self.name_entry.get() == "" or self.surname_entry.get() == "" or self.course_entry.get() == "" or  self.year_entry.get() == ""  or self.amount_entry.get() == "" or self.contact_entry.get() == "" :
            messagebox.showerror("Error!","Sorry!, All fields are required",parent=self.window)
        else:
            try:
                connection = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database,port=self.port)
                curs = connection.cursor()
                curs.execute("insert into fees (contact,amount,description,foryear,mode) values(%s,%s,%s,%s,%s)",
                                (
                                            self.contact_entry.get(),
                                            self.amount_entry.get(),
                                            self.desc.get(),
                                            self.year_entry.get(),
                                            self.cbModes.get(),
                                             ))
                connection.commit()
                connection.close()
                messagebox.showinfo('Done!', "The data has been submitted")
                self.reset_fields()
            except Exception as e:
                messagebox.showerror("Error!",f"Error due to {str(e)}",parent=self.window)

    '''Reset all the entry fields'''
    def reset_fields(self):
        self.name_entry.delete(0, END)
        self.surname_entry.delete(0, END)
        self.course_entry.delete(0, END)
        self.year_entry.delete(0, END)
        self.contact_entry.delete(0, END)


# The main function
if __name__ == "__main__":
    root = Tk()
    obj = FeesManagement(root)
    root.mainloop()
import tkinter
from tkinter import  *
from tkinter import  messagebox
import custom as cs




def stud():
    #msg=messagebox.showinfo("Message","Stud")
    m.destroy()
    import main
    root = Tk()
    obj = main.Management(root)
    root.mainloop()

def fees():
    m.destroy()
    import fees
    root = Tk()
    obj = fees.FeesManagement(root)
    root.mainloop()

def Exit():
    m.destroy()



m = tkinter.Tk()
m.geometry("320x300")
m.config(bg="deep sky blue")
lproj=Label(m,text="Student Management System", font=(cs.font_1, 18),bg="deep sky blue")
ltitle=Label(m,text="HOME SCREEN", font=(cs.font_1, 14),bg="deep sky blue")
bstud =Button (m,text="Personal Details",command=stud ,font=(cs.font_1, 12))
bfees = Button(m, text ="Fee Details",command=fees, font=(cs.font_1, 12))
bexit = Button(m, text ="Exit",command=exit, font=(cs.font_1, 12))
lproj.place(x=10,y=20, width=300)
ltitle.place(x=50,y=60, width=200)
bstud.place(x=60,y=100,width=170)
bfees.place(x=60,y=150,width=170)
bexit.place(x=60,y=200,width=170)
m.mainloop()

import tkinter
from tkinter import  *
from tkinter import  messagebox
import custom as cs




def clicked():
    if t1.get()=="" or t2.get()=="":
        messagebox.showinfo("Message", "Username / Password cannot be blank!")
    else:
        if t1.get()=="admin" and t2.get()=="admin":
            msg=messagebox.showinfo("Message","Welcome "+t1.get())
            m.destroy()
            import home
        else:
            messagebox.showinfo("Message", "Invalid username or password!")
            t1.delete(0,"")
            t2.delete(0,"")



m = tkinter.Tk()
m.geometry("320x250")
m.config(bg="deep sky blue")
lproj=Label(m,text="Student Management System", font=(cs.font_1, 18),bg="deep sky blue")
ltitle=Label(m,text="Login Form", font=(cs.font_1, 14))
l1 = Label(m,text="  Username :", font=(cs.font_1, 12),bg="deep sky blue")
t1=Entry(m)
l2 = Label(m,text="Password :", font=(cs.font_1, 12),bg="deep sky blue")
t2=Entry(m)
t2.config(show="*")

b1 = Button(m, text ="Login",command=clicked, font=(cs.font_1, 12))
lproj.place(x=10,y=20, width=300)
ltitle.place(x=50,y=60, width=200)
l1.place(x=60,y=100,width=70)
t1.place(x=170,y=100,width=80)
l2.place(x=60,y=140,width=70)
t2.place(x=170,y=140,width=80)
b1.place(x=120,y=190,width=70)
m.mainloop()
